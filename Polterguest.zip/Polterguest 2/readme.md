<p align="center">
  <h1 align="center">Godot Dialogbox Plugin</h1>
</p>
<p align="center">
  <h3>Made by Laurenz Reinthaler</h3>
 </p>

![](https://i.imgur.com/LByRB4l.png)
![](https://i.imgur.com/gfJCjsJ.png)

If you have any questions, read the wiki or watch the instructions video: https://www.youtube.com/watch?v=LVjcTBjyehU

<i>If you have any Issues or ideas open an issue on Github.com: https://github.com/Schweini07/Dialogbox</i>


